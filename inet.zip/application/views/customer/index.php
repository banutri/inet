<?php echo $headernya ?>
<?php echo $contentnya ?>
<?php echo $modals ?>
<?php echo $footernya ?>
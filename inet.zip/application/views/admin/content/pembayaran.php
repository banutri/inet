<div class="container-fluid">
<h1 class="h3 mb-2 text-gray-800">Pembayaran</h1>
	<p class="mb-4">Anda dapat mengelola pembayaran customer</p>



<!-- DataTales Example -->
<div class="card shadow mb-4">
		<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
			<h6 class="m-0 font-weight-bold text-info">Tabel Pembayaran</h6>
			
		</div>
		<div class="card-body">
			<div class="table-responsive ">
				<table class="table table-hover" id="tabel-pembayaran" width="100%" cellspacing="0">
					<thead>
						<tr>
							
							<th>#</th>
							<th>No. Pesanan</th>
							<th>Nama User</th>
							<th>Total</th>
							<th>Status</th>
							<th>Dibuat pada</th>
							<th class="no-sort">Aksi</th>
						</tr>
					</thead>
					
					
					<tbody>
                        

					
					</tbody>
					
					
				</table>
			</div>
		</div>
	</div>











</div>
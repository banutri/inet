<div class="container-fluid">
	<h1 class="h3 mb-2 text-gray-800">Pesanan</h1>
	<p class="mb-4">Anda dapat mengelola pesanan customer</p>

	<!-- DataTales Example -->
	<div class="card shadow mb-4">
	<div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
					<h6 class="m-0 font-weight-bold text-info">Tabel Pesanan</h6>
					<div class="dropdown no-arrow">
						<button type="button" class="btn btn-circle btn-success btn-sm btn-reload-table">
							<i class="fas fa-sync  fa-fw"></i>
						</button>

					</div>
				</div>
		<div class="card-body">
			<div class="table-responsive ">
				<table class="table table-hover" id="tabel-pesanan" width="100%" cellspacing="0">
					<thead>
						<tr>

							<th>#</th>
							<th>Customer</th>
							<th>Kurir</th>
							<th>Status</th>
							<th>Dibuat pada</th>
							<th>Total</th>
							<th class="no-sort">Aksi</th>
						</tr>
					</thead>


					<tbody>



					</tbody>


				</table>
			</div>
		</div>
	</div>


</div>
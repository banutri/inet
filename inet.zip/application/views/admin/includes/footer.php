<!-- Footer -->
<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
          <a href="<?php echo base_url('about') ?>" class="card-link text-body">
            <span> iNet Shop Tugas Pemrograman Web Lanjut 2020</span>
          </a>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->
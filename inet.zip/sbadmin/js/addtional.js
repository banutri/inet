$(document).ready(function () {

    /// splash content
        $( "#loader" ).delay(900).fadeOut(400, function(){
            $( "#my-content" ).fadeIn(400);
        });  
    
});

<div class="container " style="padding-top:60px;">
	


	<div class="row  ">
		<div class="col">
			<div class="card">
				<form action="<?php echo base_url('customer/update_keranjang') ?>" method="post">
				<div id="isi_keranjang">
					
				</div>

				
				<div class="card-footer footer-harga">
					<div class="row">
						<div class="col-md-10 my-1">
							<p>Total :  <span class="badge badge-info">Rp. <span class="total-harga"></span></span></p>
						</div>
						<div class="col-md my-1">
							<button type="submit" class="btn btn-info btn-block"><i class="fas fa-arrow-right"></i> Checkout</button>
						</div>
					</div>
				</div>
				</form>
			</div>
		</div>
	</div>






</div>
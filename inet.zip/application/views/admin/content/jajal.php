
<form action="<?php echo base_url('admin/update_barang') ?>" method="post" enctype="multipart/form-data">
	<input type="file" name="foto" id="">
	<input type="submit" value="Kirim">
</form>